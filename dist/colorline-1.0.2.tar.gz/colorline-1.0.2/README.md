# colorline
A module for colorful output in command line

Use  
```
pip install colorline
```
or
```
pipenv install colorline
```

to install it.  

The full docs is provided [here](http://colorline.readthedocs.io/).

